class GoogleSearch{
    constructor(){
        this.searchTextBox = $("#lst-ib");
        this.searchButton = $("input[value='Google Search']");
    }
}

export default GoogleSearch;
